﻿ขอขอบคุณที่ซื้อสคริปเว็บเช่าsshจาก SkyTsDev เเละขอให้ท่านอ่านข้อมูลด้านล่างก่อนทำการติดตั้งเเละใช้งาน

คำเตือน
เนื่องจากตัวเว็บเขียนจาก mysql ดังนั้นจึงไม่สนับสนุนบางที่ๆใช้ได้เฉพาะ mysqli

กรุณาจำชื่อผู้ใช้เเละรหัสmysqlของท่านไว้ด้วยเพื่อไปเเก้ใขในไฟล์

การตั้งค่าครั้งเเรกก่อนใช้งาน
เปิดไฟล์ setting.php
เเล้วเเก้ใขสองหัวข้อในด้านล่าง
1.#การตั้งค่าเบื้องต้น
เเละ
2.#เกี่ยวกับฐานข้อมูล


การตั้งค่าการเติมเงิน
เปิดโฟลเดอร์ topup เเล้วเปิดไฟล์ cs.2dth.club.truewallet.php
เเล้วเเก้ใขหัวข้อ 
1.//Mysql
เเละ
2.//True Money

เปิดไฟล์ config.php
เเล้วเเก้ใขหัวข้อ
1.//ข้อมูล





สำหรับการติดตั้งหากไม่เข้าใจโปรดไปดูที่
https://youtube.com/adventurerecord

150-95-25-146
Tom@22072534




<----------------------เริ่มเเบบvps---------------------------->

1.คำสั่งเข้าใช้งานในฐานะรูท
คำสั่ง - sudo su

2.อัพเดทระบบ
คำสั่ง - apt-get -y update && apt-get -y upgrade  

3.ติดตั้งคำสั่ง perl
คำสั่ง - apt-get -y install perl libnet-ssleay-perl openssl libauthen-pam-perl libpam-runtime libio-pty-perl apt-show-versions python

4.อัพเดทเเละติดตั้ง mysql
คำสั่ง - apt-get update && apt-get -y install mysql-server Tom@22072534

คำสั่ง - mysql_secure_installation

คำสั่ง - chown -R mysql:mysql /var/lib/mysql/ && chmod -R 755 /var/lib/mysql/

คำสั่ง - apt-get -y install nginx php5 php5-fpm php5-cli php5-mysql php5-mcrypt

คำสั่ง - rm /etc/nginx/sites-enabled/default && rm /etc/nginx/sites-available/default
mv /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
mv /etc/nginx/conf.d/vps.conf /etc/nginx/conf.d/vps.conf.backup
wget -O /etc/nginx/nginx.conf "https://buy.2dth.club/nginx.conf"
wget -O /etc/nginx/conf.d/vps.conf "https://buy.2dth.club/vps.conf"
sed -i 's/cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /etc/php5/fpm/php.ini
sed -i 's/listen = \/var\/run\/php5-fpm.sock/listen = 127.0.0.1:9000/g' /etc/php5/fpm/pool.d/www.conf

คำสั่ง - useradd -m 2dth && mkdir -p /home/2dth/public_html
rm /home/2dth/public_html/index.html && echo "<?php phpinfo() ?>" > /home/vps/public_html/info.php
chown -R www-data:www-data /home/2dth/public_html && chmod -R g+rw /home/vps/public_html
service php5-fpm restart && service nginx restart

5.สร้างฐานข้อมูล
คำสั่ง - mysql -u root -p

คำสั่ง - CREATE DATABASE IF NOT EXISTS 2DTHSSHVPN;EXIT;  
DROP DATABASE 2DTHSSHVPN;
6.ไปที่โฟลเดอร์ public
คำสั่ง - cd /home/2dth/public_html
chmod 777 /home/2dth/public_html/

8.chmod อีก
คำสั่ง - sudo chmod -R 777 /home/2dth/public_html

##########################การเตรียมไฟล์############################
1.เเตกไฟล์ที่ดาวน์โหลดมา ในมือถือให้ใช้ zarchiver ในคอมให้ใช้ 7zip
2.เชื่อมต่อ ftp เเล้วอัพโฟลเดอร์ขึ้นvpsของท่าน ใน /home/2dth/public_html

##########################การเข้าใช้งานเว็บ############################
ให้เปิดบราวเซอเเล้วพิม http://150.95.26.227:80
พร้อมกับติดตั้งเว็บตามขั้นตอน
<----------------------จบเเบบvps---------------------------->

<----------------------เริ่มเเบบโฮส---------------------------->
อัพโหลดไฟล์ไปที่โฮสของท่าน
สร้างดาต้าเบส mysql
ติดตั้งตามขั้นตอน
<----------------------จบเเบบโฮส---------------------------->

จบการกระทำทุกอย่างขอให้โชคดีพบปัญหาติดต่อใลน์