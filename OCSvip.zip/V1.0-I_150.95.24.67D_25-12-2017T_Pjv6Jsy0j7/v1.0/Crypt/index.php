<?
	session_start();
	session_destroy();
	header("location: https://2dth.club?curl=yes&online=ok&use=1&view=114993&per=111&redirect=yes&location=skytsdev");
?>