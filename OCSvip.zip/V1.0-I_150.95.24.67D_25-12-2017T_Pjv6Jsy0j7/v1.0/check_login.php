<?
	session_start();
include "include/db.config.inc.php";
	$strSQL = "SELECT * FROM member WHERE Username = '".trim($_POST['2dthUser'])."' OR Email = '".trim($_POST['2dthUser'])."' 
	and Password = '".trim($_POST['2dthPass'])."'";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
	if(!$objResult)
	{
			header('Location: login.php?error=pass');
	}
	else
	{
			$_SESSION["UserID"] = $objResult["UserID"];
			$_SESSION["Usernames"] = $objResult["Username"];
			$_SESSION["Status"] = $objResult["Status"];

			session_write_close();
			
			if($objResult["Status"] == "ADMIN")
			{
				header("location:profile.php");
			}
			if($objResult["Status"] == "USER")
			{
				header("location:user.php");
			}
			if($objResult["Status"] == "BAN")
			{
				header("location:ban.php");
			}
	}
	mysql_close(); 
?>