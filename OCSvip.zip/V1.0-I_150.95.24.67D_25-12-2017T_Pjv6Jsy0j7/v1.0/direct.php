<?
	session_start();
    include "include/db.config.inc.php";
	$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
    if($_SESSION['UserID'] == "")
	{
			header('Location: index.php');
	}
	else
	{
			$_SESSION["UserID"] = $objResult["UserID"];
			$_SESSION["Status"] = $objResult["Status"];

			
			if($objResult["Status"] == "ADMIN")
			{
				header("location:admin.php");
			}
			else
			{
				header("location:user.php");
			}
	}
?> 