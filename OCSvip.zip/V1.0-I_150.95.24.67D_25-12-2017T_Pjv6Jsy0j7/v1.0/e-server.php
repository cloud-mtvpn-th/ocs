<?
include("header.php");
?>
<title><?php require("setting.php"); echo $ES_2DTHEserv; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
include("nav.php");
include "include/db.config.inc.php";
	$strSQL = "SELECT * FROM SIB WHERE SID = '".$_GET["serverid"]."' ";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
?>
<html>
<head>
<title><?php require("setting.php"); echo $ES_2DTHEserv;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<form name="form1" method="post" action="es-server.php?serverid=<?=$objResult['SID'];?>">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $ES_2DTHEds;?>
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
    echo $ES_2DTHSuc;
    echo "</span>";
	}
	?>
	<?
	if($_GET['get'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>"; 
	echo $ES_2DTHErr;
	echo "</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
<div class="row">

 <div class="col-lg-6">
   <div class="input-group">
      <span class="input-group-btn">
       <button class="btn btn-default" type="button"><?php require("setting.php"); echo $ES_2DTHNam;?>  <?
	if($_GET['name'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
    echo $ES_2DTHRnam;
    echo "</span>";
	}
	?></button>
      </span>
      <input value="<?=$objResult['SIN'];?>" type="text" class="form-control" name="2dthName" placeholder="<?php require("setting.php"); echo $ES_2DTHName;?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">

 <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $ES_2DTHAdre;?>    <?
	if($_GET['ip'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
    echo $ES_2DTHRip;
    echo "</span>";
	}
	?>
</button>
      </span>
      <input value="<?=$objResult['SIA'];?>" type="text" class="form-control" name="2dthIP" placeholder="<?php require("setting.php"); echo $ES_2DTHIp;?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
<br><br>

 <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $ES_2DTHPri;?>  <?
	if($_GET['point'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
    echo $ES_2DTHRpri;
    echo "</span>";
	}
	?></button>
      </span>
      <input value="<?=$objResult['SIB'];?>" type="text" class="form-control" name="2dthPoint" placeholder="<?php require("setting.php"); echo $ES_2DTHPric;?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $ES_2DTHRegi;?> <?
	if($_GET['region'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
    echo $ES_2DTHRregi;
    echo "</span>";
	}
	?></button>
      </span>
       <select class="btn btn-default dropdown-toggle" data-toggle="dropdown" name='2dthRegion' id='2dthRegion'>
<option value=''>--</option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_1;?>'><?php require("setting.php"); echo $RS_2DTHFR_1;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_2;?>'><?php require("setting.php"); echo $RS_2DTHFR_2;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_3;?>'><?php require("setting.php"); echo $RS_2DTHFR_3;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_4;?>'><?php require("setting.php"); echo $RS_2DTHFR_4;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_5;?>'><?php require("setting.php"); echo $RS_2DTHFR_5;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_6;?>'><?php require("setting.php"); echo $RS_2DTHFR_6;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_7;?>'><?php require("setting.php"); echo $RS_2DTHFR_7;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_8;?>'><?php require("setting.php"); echo $RS_2DTHFR_8;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_9;?>'><?php require("setting.php"); echo $RS_2DTHFR_9;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_10;?>'><?php require("setting.php"); echo $RS_2DTHFR_10;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_11;?>'><?php require("setting.php"); echo $RS_2DTHFR_11;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_12;?>'><?php require("setting.php"); echo $RS_2DTHFR_12;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_13;?>'><?php require("setting.php"); echo $RS_2DTHFR_13;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_14;?>'><?php require("setting.php"); echo $RS_2DTHFR_14;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_15;?>'><?php require("setting.php"); echo $RS_2DTHFR_15;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_16;?>'><?php require("setting.php"); echo $RS_2DTHFR_16;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_17;?>'><?php require("setting.php"); echo $RS_2DTHFR_17;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_18;?>'><?php require("setting.php"); echo $RS_2DTHFR_18;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_19;?>'><?php require("setting.php"); echo $RS_2DTHFR_19;?></option>
<option value='<?php require("setting.php"); echo $RS_2DTHF_20;?>'><?php require("setting.php"); echo $RS_2DTHFR_20;?></option>
</select>
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
<br><br>

<div class="col-lg-6">
   <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $ES_2DTHVuser;?>  <?
	if($_GET['user'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
    echo $ES_2DTHRuser;
    echo "</span>";
	}
	?></button>
      </span>
      <input value="<?=$objResult['SIU'];?>" type="text" class="form-control" name="2dthUSER" placeholder="Root , Debian ,Ubuntu , Nc-user ,<?php function rand_code($len)
{
 $min_lenght= 0;
 $max_lenght = 100;
 $bigL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
 $smallL = 'abcdefghijklmnopqrstuvwxyz';
 $number = '0123456789';
 $bigB = str_shuffle($bigL);
 $smallS = str_shuffle($smallL);
 $numberS = str_shuffle($number);
 $subA = substr($bigB,0,5);
 $subB = substr($bigB,6,5);
 $subC = substr($bigB,10,5);
 $subD = substr($smallS,0,5);
 $subE = substr($smallS,6,5);
 $subF = substr($smallS,10,5);
 $subG = substr($numberS,0,5);
 $subH = substr($numberS,6,5);
 $subI = substr($numberS,10,5);
 $RandCode1 = str_shuffle($subA.$subD.$subB.$subF.$subC.$subE);
 $RandCode2 = str_shuffle($RandCode1);
 $RandCode = $RandCode1.$RandCode2;
 if ($len>$min_lenght && $len<$max_lenght)
 {
 $CodeEX = substr($RandCode,0,$len);
 }
 else
 {
 $CodeEX = $RandCode;
 }
 return $CodeEX;
}
echo rand_code(5);
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
 <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $ES_2DTHVpass;?> <?
	if($_GET['pass'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
    echo $ES_2DTHRpass;
    echo "</span>";
	}
	?></button>
      </span>
      <input value="<?=$objResult['SIP'];?>" type="text" class="form-control" name="2dthPASS" placeholder="<?php require("setting.php"); echo $ES_2DTHPass;?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
<br><br>

</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align="center">
      <input type="submit" name="Submit" value="<?php require("setting.php"); echo $ES_2DTHConf;?>" class="btn btn-default">
      <a onclick="goBack()" value="<?php require("setting.php"); echo $ES_2DTHCanc;?>" class="btn btn-default"><?php require("setting.php"); echo $ES_2DTHCanc;?></a>
</form>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
</script>
</body>
</html>