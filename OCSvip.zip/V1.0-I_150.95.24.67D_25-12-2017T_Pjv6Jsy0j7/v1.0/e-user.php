<?
include("header.php");
?>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
include "include/db.config.inc.php";
include("nav.php");
	$strSQL = "SELECT * FROM member  WHERE UserID = '".$_GET["usid"]."' ";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$objResult = mysql_fetch_array($objQuery);
?>
<html>
<head>
<title><?php require("setting.php"); echo $EU_2DTHEdp;
?> <?=$objResult["Name"];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<form name="form1" method="post" action="es-user.php?ac=yes&usid=<?echo $_GET["usid"];?>">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $EU_2DTHEdf;
?> 
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
echo $EU_2DTHSav;
echo "</span>";
	}
	?><?
	if($_GET['emaila'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $EU_2DTHEma;
echo "</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
<div class="row">

    <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHNam;
?></button>
      </span>
      <input type="text" value="<?=$objResult["Name"];?>" class="form-control" name="2dthName" placeholder="<?php require("setting.php"); echo $EU_2DTHName;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHEmai;
?></button>
      </span>
      <input value="<?=$objResult["Email"];?>" name="2dthEmail" type="email" class="form-control" placeholder="<?php require("setting.php"); echo $EU_2DTHEmail;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
<br><br>
  <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHPho;
?></button>
      </span>
      <input value="<?=$objResult["Phone"];?>" name="2dthPhone" type="number" class="form-control" placeholder="<?php require("setting.php"); echo $EU_2DTHPhon;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

<div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHToke;
?></button>
      </span>
      <input name="2dthToken" type="text" value="<?php function rand_code($len)
{
 $min_lenght= 0;
 $max_lenght = 100;
 $bigL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
 $smallL = 'abcdefghijklmnopqrstuvwxyz';
 $number = '0123456789';
 $bigB = str_shuffle($bigL);
 $smallS = str_shuffle($smallL);
 $numberS = str_shuffle($number);
 $subA = substr($bigB,0,5);
 $subB = substr($bigB,6,5);
 $subC = substr($bigB,10,5);
 $subD = substr($smallS,0,5);
 $subE = substr($smallS,6,5);
 $subF = substr($smallS,10,5);
 $subG = substr($numberS,0,5);
 $subH = substr($numberS,6,5);
 $subI = substr($numberS,10,5);
 $RandCode1 = str_shuffle($subA.$subD.$subB.$subF.$subC.$subE);
 $RandCode2 = str_shuffle($RandCode1);
 $RandCode = $RandCode1.$RandCode2;
 if ($len>$min_lenght && $len<$max_lenght)
 {
 $CodeEX = substr($RandCode,0,$len);
 }
 else
 {
 $CodeEX = $RandCode;
 }
 return $CodeEX;
}
echo rand_code(5);
?>" class="form-control" placeholder="<?php require("setting.php"); echo $EU_2DTHToken;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

<br><br>

  <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHPas;
?></button>
      </span>
      <input name="2dthPass" type="text" class="form-control" value="<?=$objResult["Password"];?>" placeholder="<?php require("setting.php"); echo $EU_2DTHPass;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHCpas;
?></button>
      </span>
      <input name="2dthCpass" type="password"  class="form-control" placeholder="<?php require("setting.php"); echo $EU_2DTHCpass;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

<br><br>

  <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHPoi;
?></button>
      </span>
      <input name="2dthPoint" type="number" class="form-control" value="<?=$objResult["Point"];?>" placeholder="<?php require("setting.php"); echo $EU_2DTHPoint;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $EU_2DTHSta;
?> <?
	if($_GET['status'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $EU_2DTHStatus;
echo "</span>";
	}
	?></button>
      </span>
       <select class="btn btn-default dropdown-toggle" data-toggle="dropdown" name='2dthStatus' id='2dthStatus'>
<option value='<?=$objResult["Status"];?>'><?=$objResult["Status"];?></option>
<option value='USER'><?php require("setting.php"); echo $EU_2DTHUs;
?></option>
<option value='ADMIN'><?php require("setting.php"); echo $EU_2DTHAd;
?></option>
<option value='BAN'><?php require("setting.php"); echo $EU_2DTHBa;
?></option>
</select>
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->


<br><br><br><br>
<div class="btn-group btn-group-justified" role="group" aria-label="...">
  <div class="btn-group" role="group">
    <button type="button" class="btn btn-default"><?=$objResult["Status"];?></button>
  </div>
  <div class="btn-group" role="group">
    <button type="button" class="btn btn-default"><?=$objResult["Username"];?></button>
  </div>
  <div class="btn-group" role="group">
    <button type="button" class="btn btn-default"><?=$objResult["UserID"];?></button>
  </div>
</div>

</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align="center">
      <input type="submit" name="Submit" value="<?php require("setting.php"); echo $EU_2DTHSave;
?>" class="btn btn-default">
      <a onclick="goBack()" value="<?php require("setting.php"); echo $EU_2DTHCance;
?>" class="btn btn-default"><?php require("setting.php"); echo $EU_2DTHCance;
?></a>
	   <a onclick="goDel()" value="<?php require("setting.php"); echo $EU_2DTHDel;
?>" class="btn btn-danger"><?php require("setting.php"); echo $EU_2DTHDel;
?></a>
</form>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
function goDel() {
    window.location="del.php?delete=yes&uid=<?=$objResult['UserID'];?>";
}
</script>
</body>
</html>
