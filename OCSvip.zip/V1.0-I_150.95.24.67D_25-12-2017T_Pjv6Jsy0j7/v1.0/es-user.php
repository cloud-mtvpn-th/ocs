<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
     include "include/db.config.inc.php";
	
	if($_POST["2dthPass"] != $_POST["2dthCpass"])
	{
		$usids = $_GET["usid"];
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $US_2DTHCpas;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='e-user.php?usid=$usids' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
echo $US_2DTHBac;
echo "</a>";
        echo " <a href='direct.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
echo $US_2DTHHom;
echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
	if($_POST["2dthCpass"] == "")
	{
        include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $US_2DTHDir;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='list-user.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
echo $US_2DTHBac;
echo "</a>";
        echo " <a href='direct.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
echo $US_2DTHHom;
echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
     else
	{
	 if($_GET["ac"] == "yes")
	 include "include/db.config.inc.php";
	 $usids = $_GET["usid"];
	  $strSQL = "UPDATE member SET Password = '".trim($_POST['2dthPass'])."' 
	  ,Name = '".trim($_POST['2dthName'])."'
	  ,Email = '".trim($_POST['2dthEmail'])."'
	  ,Phone = '".trim($_POST['2dthPhone'])."'
	  ,Token = '".trim($_POST['2dthToken'])."'
	  ,Point = '".trim($_POST['2dthPoint'])."'
	  ,Status = '".trim($_POST['2dthStatus'])."'
	   WHERE UserID = '".$_GET["usid"]."' ";
	  $objQuery = mysql_query($strSQL);
	
		header("Location: e-user.php?set=suc&usid=".$_GET["usid"]);
	
	    if($_SESSION["Status"] == "ADMIN")
	    {
	 	header("Location: e-user.php?set=suc&usid=".$_GET["usid"]);
	    }
	    else
	    {
		 header("Location: e-user.php?set=suc&usid=".$_GET["usid"]);
	    }
	 }
	mysql_close();
?>