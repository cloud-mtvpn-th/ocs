<?
include("header.php");
?>
<title><?
require("setting.php");
 if($_GET[""] == "")
 {
	 echo $FL_2DTHFile."&nbsp;-&nbsp;".$S_2DTHName;
 }
 ?></title>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
include "include/db.config.inc.php";
include("nav.php");
?>
<html>
<head>
<title><?php echo $TitleWeb = $objResult["SIN"]; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<?
if($_GET[""] == "")
 {
	 ?>
<div class="btn-group btn-group-justified" role="group" aria-label="...">
  <div class="btn-group" role="group">
    <a href="file.php?file=upload" type="button" class="btn btn-default"><?php require("setting.php"); echo $FL_2DTHUpload;?></a>
  </div>
  <div class="btn-group" role="group">
    <a type="button" class="btn btn-default"><?php require("setting.php"); echo $FL_2DTHOr;?></a>
  </div>
  <div class="btn-group" role="group">
    <a href="file.php?file=delete" type="button" class="btn btn-default"><?php require("setting.php"); echo $FL_2DTHDelete;?></a>
  </div>
</div>
<?
 }
?>


<?php
if($_GET["file"] == "delete")
 {
	 ?>
<form name="form1" method="post">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $FL_2DTHFile;?>  <?php require("setting.php"); echo $FL_2DTHDel;?> 
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	require "setting.php" ;
	echo "<span class='label label-success'>";
	echo $SS_2DTHSuc;
	echo "</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
  <div class="alert alert-danger" role="alert"><?php


if (isset($_POST['delete']))
{
	$File = $_POST["2dthFile"];
	unlink("conf/".$File.".ovpn");
	$Files = $_POST["2dthFile"];
	unlink("conf/".$Files.".ehi");
	echo $FL_2DTHDsuc;
}

?> <b><?php require("setting.php"); echo $FL_2DTHDdet;?></b></div>
<div class="row">

 <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $FL_2DTHDel;?><span class="badge"><?php require("setting.php"); echo $FL_2DTHDs;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
  <?
  include("include/db.config.inc.php");
$strSQL = "SELECT * FROM SIB";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$Num_Row = mysql_num_rows($objQuery);

$strSQL .=" order by SIN DESC";
$objQuery  = mysql_query($strSQL);
?>
                     <select class="btn btn-default dropdown-toggle" data-toggle="dropdown" name='2dthFile' id='2dthFile'>
					 <?
while($objResult = mysql_fetch_array($objQuery))
{
?>
<option value='<?=$objResult['SID'];?>'><?=$objResult['SIN'];?></option>
<?
}
?>
</select>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

<div align="center">
      <input type="submit" name="delete" value="<?php require("setting.php"); echo $FL_2DTHDconf;?>" class="btn btn-default">
      <a onclick="goBack()" href="file.php" value="<?php require("setting.php"); echo $FL_2DTHDcance;?>" class="btn btn-default"><?php require("setting.php"); echo $FL_2DTHDcance;?></a>
</form>
<?
 }
?>




<?php
if($_GET["file"] == "upload")
 {
	 ?>
<form name="form1" action="" enctype="multipart/form-data" method="post">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $FL_2DTHFile;?>  <?php require("setting.php"); echo $FL_2DTHUpl;?>  
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	require "setting.php" ;
	echo "<span class='label label-success'>";
	echo $SS_2DTHSuc;
	echo "</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
  <div class="alert alert-danger" role="alert"><?php

if (isset($_POST['upload']))
{
	$filename = $_FILES["file"]["name"];
	$file_basename = substr($filename, 0, strripos($filename, '.'));
	$file_ext = substr($filename, strripos($filename, '.')); 
	$filesize = $_FILES["file"]["size"];
	$allowed_file_types = array('.ehi','.ovpn','.kpn','.2dth');	

	if (in_array($file_ext,$allowed_file_types) && ($filesize < 2000000))
	{	
		$DTHFile = $_POST["2dthFiles"];
		$newfilename = $DTHFile . $file_ext;
		if (file_exists("conf/" . $newfilename))
		{
			echo $FL_2DTHEx;
		}
		else
		{		
			move_uploaded_file($_FILES["file"]["tmp_name"], "conf/" . $newfilename);
			echo $FL_2DTHFsuc;		
		}
	}
	elseif (empty($file_basename))
	{	
		echo $FL_2DTHEm;
	} 
	elseif ($filesize > 2000000)
	{	
		echo $FL_2DTHLg;
	}
	else
	{
		echo $FL_2DTHExt . implode(', ',$allowed_file_types);
		unlink($_FILES["file"]["tmp_name"]);
	}

}

?> <b><?php require("setting.php"); echo $FL_2DTHFdet;?></b></div>
<div class="row">

 <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <input id="file" name="file" type="file" />
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
  <?
  include("include/db.config.inc.php");
$strSQL = "SELECT * FROM SIB";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$Num_Row = mysql_num_rows($objQuery);

$strSQL .=" order by SIN DESC";
$objQuery  = mysql_query($strSQL);
?>
                     <select class="btn btn-default dropdown-toggle" data-toggle="dropdown" name='2dthFiles' id='2dthFiles'>
					 <?
while($objResult = mysql_fetch_array($objQuery))
{
?>
<option value='<?=$objResult['SID'];?>'><?=$objResult['SIN'];?></option>
<?
}
?>
</select>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

<div align="center">
      <input type="submit" name="upload" value="<?php require("setting.php"); echo $FL_2DTHFconf;?>" class="btn btn-default">
      <a onclick="goBack()" href="file.php" value="<?php require("setting.php"); echo $FL_2DTHFcance;?>" class="btn btn-default"><?php require("setting.php"); echo $FL_2DTHFcance;?></a>
</form>
<?
 }
?>


<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="file.php";
}
</script>
</body>
</html>
<?php
$TitleWeb = $objResult["SIN"];
$TitleId = $objResult["SID"];
$TitleBuy = $objResult["SIB"];
$TitleRegion = $objResult["SIT"];
?>