<?
require("setting.php");
$objConnect = mysql_connect("$S_2DTHdbhost","$S_2DTHdbuser","$S_2DTHdbpass") or die("Error Connect to Database");
$objDB = mysql_select_db("$S_2DTHdbname");
mysql_query("SET character_set_results=utf8");
mysql_query("SET character_set_client=utf8");
mysql_query("SET character_set_connection=utf8");
?>