-- phpMyAdmin SQL Dump By SkyTsDev
-- version 4.1.7
-- http://www.2dth.club
--
-- Host: localhost
-- Generation Time: 
-- Server version: 5.6.16
-- PHP Version: 5.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `2DTHSSHVPN`
--

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `UserID` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Token` varchar(60) NOT NULL,
  `Point` int(5) NOT NULL DEFAULT '0',
  `Status` enum('ADMIN','USER','BAN') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'USER',
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- dump ตาราง `member`
--

INSERT INTO `member` (`UserID`, `Username`, `Password`, `Name`, `Email`, `Phone`, `Token`, `Point`, `Status`) VALUES
(001, 'snotkk', 'lolikawaii', 'NagisaShiota', '', '0', '', 0, 'ADMIN'),
(002, 'snotkkz', 'lolikawaii', 'AinzSoulSnow', '', '0', '', 0, 'ADMIN'),
(003, 'admin', 'admin', 'Admin', '', '0', '', 0, 'ADMIN');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `SIB`
--

CREATE TABLE IF NOT EXISTS `SIB` (
  `SID` int(3) NOT NULL AUTO_INCREMENT,
  `SIA` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SIU` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'root',
  `SIP` varchar(260) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SIB` int(10) NOT NULL DEFAULT '10',
  `SIN` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '2DTHTESTVPN',
  `SIT` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;


-- --------------------------------------------------------

--
-- โครงสร้างตาราง `truemoney`
--

CREATE TABLE IF NOT EXISTS `truemoney` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `uid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `uip` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `amount` int(4) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;


-- --------------------------------------------------------

--
-- โครงสร้างตาราง `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `UID` int(3) NOT NULL AUTO_INCREMENT,
  `UU` varchar(20) NOT NULL,
  `UP` varchar(20) NOT NULL,
  `UD` date NOT NULL,
  `US` varchar(255) NOT NULL,
  `UT` varchar(20) NOT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
