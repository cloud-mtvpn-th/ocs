<?
include("header.php");
?>
<title><?php require("setting.php"); echo $CU_2DTHUs; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<body>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	

include("include/db.config.inc.php");
include("nav.php");
$strSQL = "SELECT * FROM member";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$Num_Rows = mysql_num_rows($objQuery);

$strSQL .=" order by Point DESC";
$objQuery  = mysql_query($strSQL);
?>
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $CU_2DTHDet;
?></h3>
  </div>
  <div class="panel-body">
<div class="row">
<?
while($objResult = mysql_fetch_array($objQuery))
{
?>
    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
         <?=$objResult['Username'];?><span class="badge"><a href='e-user.php?usid=<?=$objResult['UserID'];?>'><font color="white"><?php require("setting.php"); echo $CU_2DTHEd;
?></font></a></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

 

    <?
}
?>
</div><!-- /.row -->
 </div>
</div>

<?
include("footer.php");
?>
</body>
</html>