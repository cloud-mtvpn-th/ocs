<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">2DTH.CLUB</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php require('setting.php'); echo $S_2DTHUrl;
?>"><?php require("setting.php"); echo $S_2DTHName;
?></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="relog.php"><?php require("setting.php"); echo $S_2DTHBs;
?> <span class="sr-only">(2DTH.CLUB)</span></a></li>
        <li><a href="host.php"><?php require("setting.php"); echo $S_2DTHHtip;
?></a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php require("setting.php"); echo $S_2DTHTool;
?> <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="r-service.php"><?php require("setting.php"); echo $S_2DTHRserv;
?></a></li>
            <li><a href="t-service.php"><?php require("setting.php"); echo $S_2DTHTopup;
?></a></li>
            <li><a href="m-service.php"><?php require("setting.php"); echo $S_2DTHService;
?></a></li>
            <li role="separator" class="divider"></li>
            <li><a href="https://check.2dth.club/ip.php?check="><?php require("setting.php"); echo $S_2DTHChip;
?></a></li>
            <li><a href="https://skytsdev.2dth.club"><?php require("setting.php"); echo $S_2DTHserv;
?></a></li>
          </ul>
        </li>
      </ul>
      <form action="https://www.google.com/search" class="navbar-form navbar-left">
        <div class="form-group">
          <input name="q" type="text" class="form-control" placeholder="<?php require('setting.php'); echo $S_2DTHGtext;
?>">
        </div>
        <button type="submit" class="btn btn-default"><?php require("setting.php"); echo $S_2DTHGsearch;
?></button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="https://fast.com"><?php
$kb=1024;
echo "SP<!-";
flush();
$time = explode(" ",microtime());
$start = $time[0] + $time[1];
for($x=0;$x<$kb;$x++){
    echo str_pad('', 1024, '.');
    flush();
}
$time = explode(" ",microtime());
$finish = $time[0] + $time[1];
$deltat = $finish - $start;
echo "->T ". round($kb / $deltat, 3)."Kb/s";
?></a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
		  <?php require("setting.php"); echo $S_2DTHEp;
?>
		  <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="profile.php"><?php require("setting.php"); echo $S_2DTHProfile;
?></a></li>
            <li><a href="e-service.php"><?php require("setting.php"); echo $S_2DTHEprofile;
?></a></li>
            <li role="separator" class="divider"></li>
            <li><a href="https://check.2dth.club/cp.php?check=<?echo $_SERVER['SERVER_NAME'];?>&product=vpnreseller"><?php require("setting.php"); echo $S_2DTHChlicense;
?></a></li>
			<li><a href="logout.php"><?php require("setting.php"); echo $S_2DTHLogout;
?></a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>