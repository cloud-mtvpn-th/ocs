<?
include("header.php");
?>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
	
include "include/db.config.inc.php";
include("nav.php");
	$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
?>
<html>
<head>
<title><?php require("setting.php"); echo $PF_2DTHProf;?> <?=$objResult["Name"];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $PF_2DTHDet;?></h3>
  </div>
  <div class="panel-body">
<div class="row">

    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHName;?><span class="badge"><?=$objResult["Name"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHEmail;?><span class="badge"><?=$objResult["Email"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHUser;?><span class="badge"><?=$objResult["Username"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHId;?><span class="badge"><?=$objResult["UserID"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHPhone;?><span class="badge"><?=$objResult["Phone"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHToken;?><span class="badge"><?=$objResult["Token"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHPoint;?><span class="badge"><?=$objResult["Point"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHStatus;?><span class="badge"><?=$objResult["Status"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

<br><br><br><br>

<?
if($objResult['Status'] == 'ADMIN')
{
?>
		 <div class="col-lg-6">
   <ul class="list-group">
   <a href="n-server.php">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHNserv;?><span class="badge"><?php require("setting.php"); echo $PF_2DTHDnserv;?></span>
    </li>
	</a>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
	 <a href="list-server.php">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHEserv;?><span class="badge"><?php require("setting.php"); echo $PF_2DTHDeserv;?></span>
    </li>
	</a>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
   <ul class="list-group">
   <a href="list-user.php">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHEuser;?><span class="badge"><?php require("setting.php"); echo $PF_2DTHDeuser;?></span>
    </li>
	</a>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
	 <a href="tool.php">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHTool;?><span class="badge"><?php require("setting.php"); echo $PF_2DTHEtool;?></span>
    </li>
	</a>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
   <ul class="list-group">
   <a href="file.php">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHFile;?><span class="badge"><?php require("setting.php"); echo $PF_2DTHEfile;?></span>
    </li>
	</a>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
	 <a href="skytsdev.2dth.club">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PF_2DTHSup;?><span class="badge"><?php require("setting.php"); echo $PF_2DTHSupp;?></span>
    </li>
	</a>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

<?
}
?>
</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align="center">
      <a onclick="goEdit()" type="button" name="goEdit" value="<?php require('setting.php'); echo $PF_2DTHEEdf;?>" class="btn btn-default"><?php require('setting.php'); echo $PF_2DTHEEdf;?></a>
      <a onclick="goBack()" type="button" name="goBack" value="<?php require("setting.php"); echo $PF_2DTHECance;?>" class="btn btn-default"><?php require("setting.php"); echo $PF_2DTHECance;?></a>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
function goEdit() {
    window.location="e-service.php";
}
</script>
</body>
</html>
