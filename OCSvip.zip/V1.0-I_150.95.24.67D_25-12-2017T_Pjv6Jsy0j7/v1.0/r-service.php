<?
include("header.php");
?>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
include("nav.php");
?>
<html>
<head>
<title><?php require("setting.php"); echo $CT_2DTHCt; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $CT_2DTHCo;?></h3>
  </div>
  <div class="panel-body">
<div class="row">

    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHFb;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHFbl;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHLi;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHLil;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHTt;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHTtl;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHWs;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHWsl;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHYt;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHYtl;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHPh;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHPhn;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHEma;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHEmail;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $CT_2DTHOth;?><span class="badge"><?php require("setting.php"); echo $CT_2DTHOther;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

<br><br><br><br>

</div><!-- /.row -->
 </div>
</div>
<br><br>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
function goEdit() {
    window.location="e-service.php";
}
</script>
</body>
</html>
