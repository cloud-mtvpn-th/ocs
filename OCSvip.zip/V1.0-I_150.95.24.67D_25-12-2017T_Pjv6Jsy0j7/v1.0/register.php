<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title><?php require("setting.php"); echo $RS_2DTHReg;?></title>
</head>
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4 class="list-group-item-heading"><?php require("setting.php"); echo $RS_2DTHRegi;?></h4>
    <p class="list-group-item-text"><?php require("setting.php"); echo $RS_2DTHWar;?></p>

  </a>
    <div align="right" class="list-group-item">
<marquee><?php require("setting.php"); echo $RS_2DTHPos;?></marquee>

	</div>
</div>
<div class="row">
    <div class="Absolute-Center is-Responsive">
      <div id="logo-container"></div>
      <div class="col-sm-12 col-md-10 col-md-offset-1">
<form name="form1" method="post" action="s_regis.php">
	  <?
	if($_GET['user'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHRuser;
echo "</span>";
	}
	?>
	 <?
	if($_GET['usera'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHDuser;
echo "</span>";
	}
	?><br>
 <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input class="form-control" type="text" name='2dthUser' placeholder="<?php require("setting.php"); echo $RS_2DTHUser;?>"/>          
          </div>
	
	<?
	if($_GET['pass'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHRpass;
echo "</span>";
	}
	?><br>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
            <input class="form-control" type="password" name='2dthPass' placeholder="<?php require("setting.php"); echo $RS_2DTHPass;?>"/>     
          </div>

		  	<?
	if($_GET['cpass'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHWpass;
echo "</span>";
	}
	?><br>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
            <input class="form-control" type="password" name='2dthCpass' placeholder="<?php require("setting.php"); echo $RS_2DTHCpass;?>"/>     
          </div>

		  	<?
	if($_GET['name'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHRname;
echo "</span>";
	}
	?><br>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
            <input class="form-control" type="name" name='2dthName' placeholder="<?php require("setting.php"); echo $RS_2DTHName;?>"/>     
          </div>

		  	<?
	if($_GET['email'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHRemai;
echo "</span>";
	}
	?>
	<?
	if($_GET['emaila'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHDemai;
echo "</span>";
	}
	?><br>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
            <input class="form-control" type="email" name='2dthEmail' placeholder="<?php require("setting.php"); echo $RS_2DTHEmail;?>"/>     
          </div>

		  		  	<?
	if($_GET['phone'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHRpho;
echo "</span>";
	}
	?><br>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
            <input class="form-control" type="number" name='2dthPhone' placeholder="<?php require("setting.php"); echo $RS_2DTHPhone;?>"/>     
          </div>

<?
	if($_GET['check'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $RS_2DTHRacce;
echo "</span>";
	}
	?><br>
          <div class="checkbox">
            <label>
              <input name="2dthCheck" value="yes" type="checkbox"> <?php require("setting.php"); echo $RS_2DTHAccep;?>
            </label>
          </div>
          <div class="form-group">
            <input class="btn btn-def btn-block" type="submit" name="Submit" value="<?php require("setting.php"); echo $RS_2DTHSig;?>">
          </div>
          <div class="form-group text-center">
            <a href="login.php"><?php require("setting.php"); echo $RS_2DTHLog;?></a>&nbsp;|&nbsp;<a href="about.php"><?php require("setting.php"); echo $RS_2DTHTerm;?></a>
          </div>
</form>
</div>
</div>
</div>


<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</body>
</html>
