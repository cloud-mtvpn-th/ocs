<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

include "include/db.config.inc.php";
	
	if($_POST["2dthPass"] != $_POST["2dthCpass"])
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $FS_2DTHFailp;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='e-service.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $FS_2DTHBack;
        echo "</a>";
        echo " <a href='direct.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $FS_2DTHHome;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
	if($_POST["2dthCpass"] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $FS_2DTHFail;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='e-service.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $FS_2DTHBack;
        echo "</a>";
        echo " <a href='direct.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $FS_2DTHHome;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
     else
	{
	 if($_GET["ac"] == "yes")
	 include "include/db.config.inc.php";
	  $strSQL = "UPDATE member SET Password = '".trim($_POST['2dthPass'])."' 
	  ,Name = '".trim($_POST['2dthName'])."'
	  ,Email = '".trim($_POST['2dthEmail'])."'
	  ,Phone = '".trim($_POST['2dthPhone'])."'
	  ,Token = '".trim($_POST['2dthToken'])."'
	   WHERE UserID = '".$_SESSION["UserID"]."' ";
	  $objQuery = mysql_query($strSQL);
	
		header('Location: e-service.php?set=suc');
	
	    if($_SESSION["Status"] == "ADMIN")
	    {
	 	header('Location: e-service.php?set=suc');
	    }
	    else
	    {
		 header('Location: e-service.php?set=suc');
	    }
       
	 }
	mysql_close();
?>