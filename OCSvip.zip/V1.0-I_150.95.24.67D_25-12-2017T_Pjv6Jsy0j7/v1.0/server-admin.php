<?
include("header.php");
?>
<title><?php require("setting.php"); echo $TitleWeb = $objResult["SIN"]; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
include "include/db.config.inc.php";
include("nav.php");
	$strSQL = "SELECT * FROM SIB  WHERE SID = '".$_GET["s"]."' ";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$objResult = mysql_fetch_array($objQuery);
?>
<html>
<head>
<title><?php echo $TitleWeb = $objResult["SIN"]; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<form name="form1" method="post" action="a-server.php?token=<?
function generateRandomString($length = 100) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0987654312';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
echo generateRandomString();
?>&vc=<?php echo $TitleId = $objResult['SID']; ?>&secretkey=<?php 
  $num = mt_rand(1000000000,1569325056); 
  printf("%d", $num);
  ?>&l=error&price=<?php echo $TitleBuy = $objResult['SIB']; ?>&rc=<?php echo $TitleBuy = $objResult['SIB']; ?>&dc=<?php echo $TitleBuy = $objResult['SIB']; ?>&bc=<?php
  $arr = array(
    "0" => "ABTszb359szthSHT",
    "1" => "XngchXTtxzthCYJC3",
	"2" => "QWxthj76thdx",
	"3" => "23rtyhaszRh2i",
	"4" => "9xrhsrY-81",
	"5" => "zxzthnEni8",
	"6" => "qXRGp0a4erg",
	"7" => "xbzryh4SYRxbx6",
	"8" => "yDJTSJ6r-w",
	"9" => "4HJSDXJTNxnx3");

    $word = $objResult['SIB'];
    echo strtr($word,$arr);?>&bt=<?php 
  $nums = mt_rand(10,100); 
  printf("%d", $nums);
  ?>&re=i&nc=<?php echo $TitleWeb; ?>&ni=90">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $SS_2DTHCre;?>  <?php echo $TitleWeb = $objResult["SIN"]; ?> 
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	require "setting.php" ;
	echo "<span class='label label-success'>";
	echo $SS_2DTHSuc;
	echo "</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
  <div class="alert alert-danger" role="alert"><?php require("setting.php"); echo $SS_2DTHWar;?> <b><?php require("setting.php"); echo $SS_2DTHChe;?></b></div>
<div class="row">

 <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $SS_2DTHServ;?><span class="badge"><?=$objResult['SIN'];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $SS_2DTHPri;?><span class="badge"><?=$objResult['SIB'];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

 <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $SS_2DTHIp;?><span class="badge"><?=$objResult['SIA'];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $SS_2DTHPort;?><span class="badge"><?php require("setting.php"); echo $S_2DTHPossh;?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>


    <div class="col-lg-6">
	  <?
	if($_GET['user'] == '')
	{
		
	}
	else
	{
	require "setting.php" ;
	echo "<span class='label label-danger'>";
	echo $SS_2DTHRuser;
	echo "</span>";
	}
	?>
	 <?
	if($_GET['usera'] == '')
	{
		
	}
	else
	{
	require "setting.php" ;
	echo "<span class='label label-danger'>";
	echo $SS_2DTHDub;
	echo "</span>";
	}
	?>
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $SS_2DTHNam;?></button>
      </span>
      <input type="text" class="form-control" name="2dthUser" placeholder="<?php require("setting.php"); echo $SS_2DTHName;?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
  <?
	if($_GET['pass'] == '')
	{
		
	}
	else
	{
	require "setting.php" ;
	echo "<span class='label label-danger'>";
	echo $SS_2DTHRpas;
	echo "</span>";
	}
	?>
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("setting.php"); echo $SS_2DTHPas;?></button>
      </span>
      <input name="2dthPass" type="text" class="form-control" placeholder="<?php require("setting.php"); echo $SS_2DTHPass;?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->


</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align="center">
      <input type="submit" name="Submit" value="<?php require("setting.php"); echo $SS_2DTHConf;?>" class="btn btn-default">
      <a onclick="goBack()" value="<?php require("setting.php"); echo $SS_2DTHCanc;?>" class="btn btn-default"><?php require("setting.php"); echo $SS_2DTHCanc;?></a>
</form>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
</script>
</body>
</html>
<?php
$TitleWeb = $objResult["SIN"];
$TitleId = $objResult["SID"];
$TitleBuy = $objResult["SIB"];
$TitleRegion = $objResult["SIT"];
?>