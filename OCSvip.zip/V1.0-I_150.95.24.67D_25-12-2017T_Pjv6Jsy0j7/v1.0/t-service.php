<?
include("header.php");
?>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
	require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
	
include "include/db.config.inc.php";
include("nav.php");
	$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
?>
<html>
<head>
<title><?php require("setting.php"); echo $PS_2DTHTway;?> <?=$objResult["Name"];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $PS_2DTHDet;?></h3>
  </div>
  <div class="panel-body">
<div class="row">

    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PS_2DTHNam;?><span class="badge"><?=$objResult["Name"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PS_2DTHPoi;?><span class="badge"><?=$objResult["Point"];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

    <div class="col-lg-6">
	<a href="topup/cache.php?url=tmpay.php">
   <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PS_2DTHTm;?><span class="badge"><?php require("setting.php"); echo $PS_2DTHTmm;?></span>
    </li>
</ul>
</a>
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
  <a href="topup/cache.php?url=tmwpay.php">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PS_2DTHTmw;?><span class="badge"><?php require("setting.php"); echo $PS_2DTHTmwm;?></span>
    </li>
</ul>
</a>
  </div><!-- /.col-lg-6 -->
<br><br>

  <div class="col-lg-6">
  <a href="topup/cache.php?url=twpay.php">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PS_2DTHTw;?><span class="badge"><?php require("setting.php"); echo $PS_2DTHTwm;?></span>
    </li>
</ul>
</a>
  </div><!-- /.col-lg-6 -->

    <div class="col-lg-6">
	<a href="#">
     <ul class="list-group">
  <li class="list-group-item">
        <?php require("setting.php"); echo $PS_2DTHTo;?><span class="badge"><?php require("setting.php"); echo $PS_2DTHTe;?></span>
    </li>
</ul>
</a>
  </div><!-- /.col-lg-6 -->
<br><br>

</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align="center">
      <input onclick="goEdit()" type="button" name="Submit" value="<?php require("setting.php"); echo $PS_2DTHPro;?>" class="btn btn-default">
      <input onclick="goBack()" name="Cancel" value="<?php require("setting.php"); echo $PS_2DTHCanc;?>" class="btn btn-default">

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="profile.php";
}
function goEdit() {
    window.location="e-service.php";
}
</script>
</body>
</html>
