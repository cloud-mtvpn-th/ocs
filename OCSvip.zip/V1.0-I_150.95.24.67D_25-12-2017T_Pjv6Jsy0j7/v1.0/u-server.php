<?
include("header.php");
?>
<title><?php require("setting.php"); echo $AS_2DTHSuc; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "USER")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRuser;
		echo $S_2DTHAdmin;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
include "include/db.config.inc.php";
include("nav.php");
	$strSQL = "SELECT * FROM SIB  WHERE SID = '".$_GET["s"]."' ";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$objResult = mysql_fetch_array($objQuery);
?>
<html>
<head>
<title><?require("setting.php"); echo $AS_2DTHSuc;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<meta charset="UTF-8">
<?
    require("setting.php");
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
if(trim($_POST["2dthUser"]) == "")
{
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHUser;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit();	
}	
if(trim($_POST["2dthPass"]) == "")
{
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHPass;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit();	
}	

if(trim($_GET["bc"]) == "")
{
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHErr;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit();	
}	

if(trim($_GET["bt"]) == "")
{
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHErr;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit();	
}	

if(trim($_GET["nc"]) == "")
{
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHErr;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit();	
}	

if(trim($_GET["bc"]) == "0")
{
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHErr;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit();	
}	

$TdthUser = $_POST["2dthUser"];
$TdthPass = $_POST["2dthPass"];
$arr = array(
	"ABTszb3txzthCYJC359szthSHT" => "0",
    "XngchXTt6thdxxzthCYJC3" => "1",
	"QWxthjszRh2i76thdx" => "2",
	"23rtyhaszY-81Rh2i" => "3",
	"9xrhsrhnEni8Y-81" => "4",
	"zxzth0a4ergEni8" => "5",
	"qXRGp0a4SYRxbx64erg" => "6",
	"xbzryh4SJ6r-wSYRxbx6" => "7",
	"yDJTSJ6r-TNxnx3w" => "8",
	"4HJSDXdtD-HJTNxnx3" => "9");

$word = $_GET["bc"];
$Pointb = strtr($word,$arr);
$DateEX = date("Y-m-d", strtotime("+31 days"));
$API = "http://api-moneywallet.byethost22.com/testtextecho.php?apitruemoney=1&redirect=0&controlother=1&privatekey=ai46430225&v=php&curl=no&main=https://2dth.club";
include "include/db.config.inc.php";
$strSQL="select * from member WHERE UserID = '".$_SESSION["UserID"]."' ";
$objQuery = mysql_query($strSQL);
$objResult = mysql_fetch_array($objQuery);

if($objResult<1) {
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHErr;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";

exit();
}

if($objResult["Point"]<$Pointb){
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHRpoi;
echo "$Pointb</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
exit() ;
}

else
{
$strSQL = "SELECT * FROM user WHERE UU = '".trim($_POST['2dthUser'])."' ";
$objQuery = mysql_query($strSQL);
$objResult = mysql_fetch_array($objQuery);

 if($objResult)
 {
 echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHNoti;
echo "</h3>
  </div>
  <div class='panel-body'>

<span class='label label-danger'>";
echo $AS_2DTHDub;
echo "</span>

 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
 }

 else
{
$strSQL="update member set Point=Point-'$Pointb' WHERE UserID = '".$_SESSION["UserID"]."' ";
$objQuery = mysql_query($strSQL);

if($objQuery) 
 {
  $strSQL = "INSERT INTO user (UU,UP,UD,US,UT) VALUES ('".$_POST["2dthUser"]."', 
  '".$_POST["2dthPass"]."',
  '".date("Y-m-d", strtotime("+31 days"))."',
  '".$_SESSION["Usernames"]."',
  '".$Pointb."'
  )";
  $objQuery = mysql_query($strSQL);
  if($objQuery) 
 {
$strSQL = "SELECT * FROM SIB  WHERE SID = '".$_GET["vc"]."' ";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$objResult = mysql_fetch_array($objQuery);
include('Net/SSH2.php');
$Username = $_POST['2dthUser'];
$Password = $_POST['2dthPass'];
$IP = $objResult['SIA'];
$User = $objResult['SIU'];
$Pass = $objResult['SIP'];
$Div1 = "<div class='alert alert-warning' role='alert'>";
$LoginFail = $AS_2DTHWar;
$Div2 = "</div>";
$ssh = new Net_SSH2($IP);
$ssh->login($User, $Pass) or die("$Div1 $LoginFail $Div2");
$ssh->getServerPublicHostKey();
$cmd = "sudo useradd -d /home/$Username -p $(perl -e'print crypt(\"$Password\", \"cu\")') -e `date -d '31 days' +'%Y-%m-%d'` $Username";
$cmdr = $ssh->exec($cmd);
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $AS_2DTHDet;
echo "</h3>
  </div>
  <div class='panel-body'>
<div class='row'>

    <div class='col-lg-6'>
   <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $AS_2DTHNam;
echo "<span class='badge'> $TdthUser </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $AS_2DTHPas;
echo "<span class='badge'> $TdthPass </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

<div class='col-lg-6'>
   <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $AS_2DTHPri;
echo "<span class='badge'> $Pointb </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $AS_2DTHDay;
echo "<span class='badge'> $DateEX </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
	  echo $AS_2DTHHome;
	  echo "</a>";
      echo "<a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
	  echo $AS_2DTHPoi;
	  echo "</a>";
 }
  
  }
	 }
 }

mysql_close();
?>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="relog.php";
}
function goHome() {
    window.location="profile.php";
}
</script>
</body>
</html>
<?php
$TitleWeb = $objResult["SIN"];
$TitleId = $objResult["SID"];
$TitleBuy = $objResult["SIB"];
$TitleRegion = $objResult["SIT"];
?>